from electroncash.i18n import _

fullname = 'Waifu token'
description = '%s\n%s' % (_("View your waifu collection in full glory."), _(""))
available_for = ['qt']
