### Waifu plugin for Electron Cash

Download the plugin zip

Open Electron Cash -> Tools -> Installed Plugins

Add Plugin -> Select dowloaded zip

...

Profit!
